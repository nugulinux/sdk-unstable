/*
 * Copyright (c) 2019 SK Telecom Co., Ltd. All rights reserved.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#ifndef __NUGU_H__
#define __NUGU_H__

#ifdef __cplusplus
extern "C" {
#endif

/**
 * @file nugu.h
 * @defgroup nugu NUGU SDK information
 * @ingroup SDKBase
 * @brief NUGU SDK information
 *
 * @{
 */

#define NUGU_VERSION "0.23.0"
#define NUGU_VERSION_MAJOR 0
#define NUGU_VERSION_MINOR 23
#define NUGU_VERSION_PATCH 0
#define NUGU_VERSION_NUMBER (((NUGU_VERSION_MAJOR) << 16) \
    | ((NUGU_VERSION_MINOR) << 8) | (NUGU_VERSION_PATCH))

#define NUGU_USERAGENT_FORMAT "OpenSDK/0.23.0 (Linux) Client/%s %s"

#define NUGU_REGISTRY_URL "https://reg-http.sktnugu.com"

#define NUGU_PLUGIN_DIR "/usr/lib/aarch64-linux-gnu/nugu"

/**
 * @}
 */

#ifdef __cplusplus
}
#endif

#endif
